# sample-html-css

This code is used for the programming workshop week 2 to make static website